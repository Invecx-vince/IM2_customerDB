from django.apps import AppConfig


class DshbordConfig(AppConfig):
    name = 'dshbord'
